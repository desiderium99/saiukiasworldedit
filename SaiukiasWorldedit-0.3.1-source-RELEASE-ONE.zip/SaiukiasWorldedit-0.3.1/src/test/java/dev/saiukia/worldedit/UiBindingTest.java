package dev.saiukia.worldedit;
import org.bson.BsonDocument;
import org.bson.BsonString;
public class UiBindingTest {
  public static void main(String[] args) {
    BsonDocument event = new BsonDocument("Action",new BsonString("hollow"));
    SaiukiasWorldeditPage.Click click = SaiukiasWorldeditPage.Click.CODEC.decode(event);
    if (!"hollow".equals(click.action) || click.block != null || click.from != null) throw new AssertionError("missing non-required field decode");
    System.out.println("PASS: hollow/status event decodes without block fields");
  }
}
