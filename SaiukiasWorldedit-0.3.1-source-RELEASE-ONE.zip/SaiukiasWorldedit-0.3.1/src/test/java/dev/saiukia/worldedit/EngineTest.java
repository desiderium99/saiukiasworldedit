package dev.saiukia.worldedit;

import java.util.*;
import static dev.saiukia.worldedit.WorldEditEngine.*;

public class EngineTest {
    static class Mock implements WorldAccess {
        final Map<Pos,String> blocks=new HashMap<>();
        Pos unloaded;
        @Override public String get(Pos p){return blocks.getOrDefault(p,"Empty");}
        @Override public void set(Pos p,String key){blocks.put(p,key);}
        @Override public boolean isLoaded(Pos p){return !p.equals(unloaded);}
    }
    static void check(boolean expression,String message){if(!expression)throw new AssertionError(message);}
    static void finish(WorldEditEngine e){
        int ticks=0;
        while(e.busy() && ticks++<10000){
            int done=e.step(41,System.nanoTime()+1_000_000_000L);
            check(done<=41,"processed too many blocks in one tick: "+done);
        }
        check(!e.busy(),"job did not finish");
    }
    static void testMain(){
        Mock world=new Mock();WorldEditEngine e=new WorldEditEngine(world,5);
        e.pos1(new Pos(0,0,0));e.pos2(new Pos(19,19,19));
        check(e.region().volume()==8000,"selection volume");
        e.startFill("Rock_Stone");
        check(e.busy(),"fill should queue");
        int first=e.step(41,System.nanoTime()+1_000_000_000L);
        check(first==41,"first tick should do 41");
        check(e.busy(),"job should still be pending");
        finish(e);check(e.lastResult().contains("8000 modified"),"fill count");
        // Restore a few distinct surface materials and verify hollow does not overwrite them.
        world.set(new Pos(0,0,0),"Soil_Dirt");world.set(new Pos(19,19,19),"Wood_Oak");
        e.startHollow();finish(e);
        check(e.lastResult().contains("5832 modified"),"interior 18^3 hollow count: "+e.lastResult());
        check(world.get(new Pos(0,0,0)).equals("Soil_Dirt"),"hollow preserves one corner");
        check(world.get(new Pos(19,19,19)).equals("Wood_Oak"),"hollow preserves another corner");
        check(world.get(new Pos(1,1,1)).equals("Empty"),"hollow clears interior");
        check(world.get(new Pos(0,1,1)).equals("Rock_Stone"),"hollow preserves surface");
        e.startUndo();finish(e);check(world.get(new Pos(1,1,1)).equals("Rock_Stone"),"undo hollow");
        e.startRedo();finish(e);check(world.get(new Pos(1,1,1)).equals("Empty"),"redo hollow");
        e.startReplace("Rock_Stone","Sand");finish(e);
        check(world.get(new Pos(0,1,1)).equals("Sand"),"replace");
        e.startCopy();finish(e);check(e.hasClipboard(),"clipboard");
        e.startPaste(new Pos(30,0,0),false);finish(e);
        check(world.get(new Pos(30,0,0)).equals("Soil_Dirt"),"paste origin");
        check(world.get(new Pos(31,1,1)).equals("Empty"),"paste empty interior");
        e.startUndo();finish(e);check(world.get(new Pos(30,0,0)).equals("Empty"),"undo paste");
        e.startRedo();finish(e);check(world.get(new Pos(30,0,0)).equals("Soil_Dirt"),"redo paste");
    }
    static void testCancellationAndFailure(){
        Mock world=new Mock();WorldEditEngine e=new WorldEditEngine(world,5);
        e.pos1(new Pos(0,0,0));e.pos2(new Pos(299,0,0));
        e.startFill("A");e.step(17,System.nanoTime()+1_000_000_000L);
        e.cancel();check(!e.busy(),"cancel");
        e.startUndo();finish(e);
        check(world.get(new Pos(0,0,0)).equals("Empty"),"partial edits undoable after cancel");
        // Even with unloaded sections, earlier edits remain undoable.
        world.unloaded=new Pos(23,0,0);
        e.startFill("B");finish(e);
        check(e.lastResult().contains("Stopped"),"unloaded failure notification: "+e.lastResult());
        check(world.get(new Pos(0,0,0)).equals("B"),"partial edit recorded");
        world.unloaded=null;
        e.startUndo();finish(e);
        check(world.get(new Pos(0,0,0)).equals("Empty"),"partial edit undoable after unloaded failure");
        e.pos2(new Pos(0,0,0));e.startHollow();finish(e);
        check(e.lastResult().contains("0 modified"),"single block hollow no-op");
    }
    static void testBigNoLimit(){
        Mock world=new Mock();WorldEditEngine e=new WorldEditEngine(world,5);
        e.pos1(new Pos(0,0,0));e.pos2(new Pos(109,99,0));
        check(e.region().volume()==11000,"no old cap");
        e.startFill("A");finish(e);
        check(e.lastResult().contains("11000 modified"),"large fill");
        e.startHollow();finish(e);
        check(e.lastResult().contains("0 modified"),"one block thick no interior");
    }
    public static void main(String[] args){testMain();testCancellationAndFailure();testBigNoLimit();System.out.println("PASS: 8k & 11k edits, batch sizing, hollow preserves shell, undo/redo, copy/paste, replace, cancel & failure rollback via undo");}
}
