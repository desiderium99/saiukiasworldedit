package dev.saiukia.worldedit;

import com.hypixel.hytale.component.*;
import com.hypixel.hytale.component.query.Query;
import com.hypixel.hytale.component.system.EntityEventSystem;
import com.hypixel.hytale.component.system.tick.TickingSystem;
import com.hypixel.hytale.server.core.Message;
import com.hypixel.hytale.server.core.asset.type.blocktype.config.BlockType;
import com.hypixel.hytale.server.core.command.system.CommandContext;
import com.hypixel.hytale.server.core.command.system.basecommands.AbstractPlayerCommand;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.inventory.ItemStack;
import com.hypixel.hytale.server.core.modules.interaction.event.InteractionChainStartEvent;
import com.hypixel.hytale.server.core.event.events.ecs.DamageBlockEvent;
import com.hypixel.hytale.server.core.event.events.ecs.BreakBlockEvent;
import com.hypixel.hytale.server.core.event.events.ecs.PlaceBlockEvent;
import com.hypixel.hytale.server.core.permissions.PermissionsModule;
import com.hypixel.hytale.server.core.plugin.JavaPlugin;
import com.hypixel.hytale.server.core.plugin.JavaPluginInit;
import com.hypixel.hytale.server.core.universe.PlayerRef;
import com.hypixel.hytale.server.core.universe.world.World;
import com.hypixel.hytale.server.core.universe.world.chunk.BlockOperations;
import com.hypixel.hytale.server.core.universe.world.chunk.section.BlockSection;
import com.hypixel.hytale.server.core.universe.world.storage.ChunkStore;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;
import com.hypixel.hytale.server.core.universe.world.accessor.SectionReader;
import com.hypixel.hytale.protocol.BlockPosition;
import com.hypixel.hytale.protocol.InteractionType;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class SaiukiasWorldeditPlugin extends JavaPlugin {
    private final Map<UUID, Session> sessions = new ConcurrentHashMap<>();
    public SaiukiasWorldeditPlugin(JavaPluginInit init) { super(init); }

    @Override protected void setup() {
        getCommandRegistry().registerCommand(new OpenCommand());
        getCommandRegistry().registerCommand(new WandCommand());
        getEntityStoreRegistry().registerSystem(new SelectSystem());
        getEntityStoreRegistry().registerSystem(new ProtectDamageSystem());
        getEntityStoreRegistry().registerSystem(new ProtectBreakSystem());
        getEntityStoreRegistry().registerSystem(new ProtectPlaceSystem());
        getEntityStoreRegistry().registerSystem(new EditTickSystem());
    }

    // Hytale /op add gives the user the built-in group "hytale:Admin".
    // Check the exact built-in operator membership, rather than requiring any
    // custom group named "admin" or "owner", or allowing users with a single
    // unrelated delegated permission to use world editing.
    static boolean isOperatorGroups(Set<String> groups) {
        return groups != null && groups.contains("hytale:Admin");
    }

    static boolean authorized(PlayerRef player) {
        PermissionsModule permissions = PermissionsModule.get();
        return player != null && permissions != null
                && isOperatorGroups(permissions.getGroupsForUser(player.getUuid()));
    }

    Session session(PlayerRef player, World world) {
        Session s = sessions.computeIfAbsent(player.getUuid(), ignored -> new Session());
        if (s.world != world) {
            if (s.engine != null) s.engine.cancel();
            s.world = world;
            s.worldId = world.getName();
            s.engine = new WorldEditEngine(new Adapter(world), 5);
            s.wandItem = null;
        }
        s.operator = player;
        return s;
    }

    static final class Session {
        World world;
        PlayerRef operator;
        long lastProgressTick;
        String worldId;
        String wandItem;
        WorldEditEngine engine;
        int nextCorner = 1;
    }

    static WorldEditEngine.Pos atFeet(PlayerRef player) {
        var p = player.getTransform().getPosition();
        return new WorldEditEngine.Pos((int) Math.floor(p.x), (int) Math.floor(p.y), (int) Math.floor(p.z));
    }

    static final class Adapter implements WorldEditEngine.WorldAccess {
        final ChunkStore chunks;
        final SectionReader reader;
        Adapter(World w) { chunks = w.getChunkStore(); reader = new SectionReader(chunks); }
        @Override public boolean isLoaded(WorldEditEngine.Pos p) {
            return reader.hasStorageInMemory(p.x(), p.y(), p.z());
        }
        @Override public String get(WorldEditEngine.Pos p) {
            if (!isLoaded(p)) throw new IllegalStateException("Chunk not loaded at " + p);
            int id = reader.getBlock(p.x(), p.y(), p.z());
            var type = BlockType.getAssetMap().getAsset(id);
            return type == null ? "Empty" : type.getId();
        }
        @Override public void set(WorldEditEngine.Pos p, String key) {
            if (!isLoaded(p)) throw new IllegalStateException("Chunk not loaded at " + p);
            BlockType type = "Empty".equalsIgnoreCase(key) ? BlockType.EMPTY : BlockType.getAssetMap().getAsset(key);
            if (type == null) throw new IllegalArgumentException("Unknown block: " + key);
            var ref = chunks.getChunkSectionReferenceAtBlock(p.x(), p.y(), p.z());
            if (ref == null || !ref.isValid()) throw new IllegalStateException("Chunk unloaded at " + p);
            int id = "Empty".equalsIgnoreCase(key) ? BlockType.EMPTY_ID : BlockType.getAssetMap().getIndex(type.getId());
            BlockOperations.setBlock(chunks, ref, p.x(), p.y(), p.z(), id, type, 0, 0, 4);
        }
    }

    final class OpenCommand extends AbstractPlayerCommand {
        OpenCommand() { super("we", "Open Saiukias Worldedit (OP only)"); requireNoPermission(); }
        @Override protected void execute(CommandContext ctx, Store<EntityStore> store, Ref<EntityStore> ref, PlayerRef pr, World world) {
            if (!authorized(pr)) { ctx.sendMessage(Message.raw("Saiukias Worldedit: Operator permissions required. Use /op add <player> from the server console.")); return; }
            Player player = store.getComponent(ref, Player.getComponentType());
            if (player == null) return;
            session(pr, world);
            player.getPageManager().openCustomPage(ref, store, new SaiukiasWorldeditPage(SaiukiasWorldeditPlugin.this, pr, world));
        }
    }

    final class WandCommand extends AbstractPlayerCommand {
        WandCommand() { super("wewand", "Bind the held item as a WorldEdit selection wand (OP only)"); requireNoPermission(); }
        @Override protected void execute(CommandContext ctx, Store<EntityStore> store, Ref<EntityStore> ref, PlayerRef pr, World world) {
            if (!authorized(pr)) { ctx.sendMessage(Message.raw("Saiukias Worldedit: Operator permissions required. Use /op add <player> from the server console.")); return; }
            Player player = store.getComponent(ref, Player.getComponentType());
            if (player == null) return;
            ItemStack held = player.getInventory().getItemInHand();
            if (held == null || ItemStack.isEmpty(held)) { ctx.sendMessage(Message.raw("Hold any tool and enter /wewand.")); return; }
            Session s = session(pr, world);
            if (held.getItemId().equals(s.wandItem)) {
                s.wandItem = null;
                ctx.sendMessage(Message.raw("Saiukias Worldedit wand unbound."));
            } else {
                s.wandItem = held.getItemId();
                ctx.sendMessage(Message.raw("Bound " + s.wandItem + " as the selection wand. Left click = pos1, right click = pos2."));
            }
        }
    }

    final class SelectSystem extends EntityEventSystem<EntityStore, InteractionChainStartEvent> {
        SelectSystem() { super(InteractionChainStartEvent.class); }
        @Override public Query<EntityStore> getQuery() { return Query.and(Player.getComponentType(), PlayerRef.getComponentType()); }
        @Override public void handle(int index, ArchetypeChunk<EntityStore> archetype, Store<EntityStore> store, CommandBuffer<EntityStore> commands, InteractionChainStartEvent event) {
            InteractionType type = event.getType();
            if (type != InteractionType.Primary && type != InteractionType.Secondary) return;
            PlayerRef pr = archetype.getComponent(index, PlayerRef.getComponentType());
            if (!authorized(pr)) return;
            Session s = sessions.get(pr.getUuid());
            if (s == null || s.wandItem == null) return;
            var context = event.getContext();
            if (context == null) return;
            ItemStack held = context.getHeldItem();
            if (held == null || !s.wandItem.equals(held.getItemId())) return;
            BlockPosition bp = context.getTargetBlock();
            if (bp == null) return;
            World world = store.getExternalData().getWorld();
            s = session(pr, world);
            WorldEditEngine.Pos pos = new WorldEditEngine.Pos(bp.x, bp.y, bp.z);
            if (type == InteractionType.Primary) s.engine.pos1(pos); else s.engine.pos2(pos);
            event.setCancelled(true);
            pr.sendMessage(Message.raw("Saiukias Worldedit " + (type == InteractionType.Primary ? "pos1" : "pos2") + ": " + bp.x + ", " + bp.y + ", " + bp.z));
        }
    }

    // A cancelled interaction-chain start alone does NOT prevent all vanilla
    // damage, breaking, or placement paths in Hytale 0.7.2. Guard the actual
    // cancellable block events too, but only for an actively bound wand and OP.
    boolean activeWand(PlayerRef player, ItemStack item) {
        if (player == null || !authorized(player) || item == null || ItemStack.isEmpty(item)) return false;
        Session session = sessions.get(player.getUuid());
        return session != null && session.wandItem != null && session.wandItem.equals(item.getItemId());
    }

    final class ProtectDamageSystem extends EntityEventSystem<EntityStore, DamageBlockEvent> {
        ProtectDamageSystem() { super(DamageBlockEvent.class); }
        @Override public Query<EntityStore> getQuery() { return Query.and(Player.getComponentType(), PlayerRef.getComponentType()); }
        @Override public void handle(int index, ArchetypeChunk<EntityStore> archetype, Store<EntityStore> store, CommandBuffer<EntityStore> commands, DamageBlockEvent event) {
            PlayerRef player = archetype.getComponent(index, PlayerRef.getComponentType());
            if (!activeWand(player, event.getItemInHand())) return;
            event.setCancelled(true);
            // Set Pos1 here as a fallback for client-driven block damage paths
            // which don't deliver InteractionChainStartEvent first.
            var block = event.getTargetBlock();
            if (block == null) return;
            Session session = session(player, store.getExternalData().getWorld());
            WorldEditEngine.Pos pos = new WorldEditEngine.Pos(block.x, block.y, block.z);
            if (!pos.equals(session.engine.pos1())) {
                session.engine.pos1(pos);
                player.sendMessage(Message.raw("Saiukias Worldedit pos1: " + block.x + ", " + block.y + ", " + block.z));
            }
        }
    }

    final class ProtectBreakSystem extends EntityEventSystem<EntityStore, BreakBlockEvent> {
        ProtectBreakSystem() { super(BreakBlockEvent.class); }
        @Override public Query<EntityStore> getQuery() { return Query.and(Player.getComponentType(), PlayerRef.getComponentType()); }
        @Override public void handle(int index, ArchetypeChunk<EntityStore> archetype, Store<EntityStore> store, CommandBuffer<EntityStore> commands, BreakBlockEvent event) {
            PlayerRef player = archetype.getComponent(index, PlayerRef.getComponentType());
            if (activeWand(player, event.getItemInHand())) event.setCancelled(true);
        }
    }

    final class ProtectPlaceSystem extends EntityEventSystem<EntityStore, PlaceBlockEvent> {
        ProtectPlaceSystem() { super(PlaceBlockEvent.class); }
        @Override public Query<EntityStore> getQuery() { return Query.and(Player.getComponentType(), PlayerRef.getComponentType()); }
        @Override public void handle(int index, ArchetypeChunk<EntityStore> archetype, Store<EntityStore> store, CommandBuffer<EntityStore> commands, PlaceBlockEvent event) {
            PlayerRef player = archetype.getComponent(index, PlayerRef.getComponentType());
            if (activeWand(player, event.getItemInHand())) event.setCancelled(true);
        }
    }

    // Runs from the engine's ECS tick callback on the same world thread that handles edits.
    // Budget is shared by all active jobs in a world, so several operators cannot each
    // monopolize a full tick. The wall-clock guard is a second protection against stalls.
    final class EditTickSystem extends TickingSystem<EntityStore> {
        @Override public void tick(float dt, int tickIndex, Store<EntityStore> store) {
            World world = store.getExternalData().getWorld();
            if (world == null) return;
            int remaining = 512;
            long deadline = System.nanoTime() + 2_000_000L; // target about 2 ms total, best effort
            for (Session s : sessions.values()) {
                if (remaining <= 0 || System.nanoTime() >= deadline) break;
                if (s.world != world || s.engine == null || !s.engine.busy()) continue;
                PlayerRef operator = s.operator;
                if (!authorized(operator) || !operator.isValid()) {
                    s.engine.cancel(); // retain partial edits in undo history
                    continue;
                }
                int scanned = s.engine.step(Math.min(remaining, 512), deadline);
                remaining -= scanned;
                long tick = world.getTick();
                if (!s.engine.busy()) {
                    operator.sendMessage(Message.raw("Saiukias Worldedit: " + s.engine.lastResult()));
                } else if (tick - s.lastProgressTick >= 40) {
                    s.lastProgressTick = tick;
                    operator.sendMessage(Message.raw("Saiukias Worldedit: " + s.engine.status()));
                }
            }
        }
    }

    static void validateBlock(String key) {
        if (key == null || key.isBlank()) throw new IllegalArgumentException("Enter a block ID for this operation");
        if (!"Empty".equalsIgnoreCase(key) && BlockType.getAssetMap().getAsset(key) == null)
            throw new IllegalArgumentException("Unknown block ID: " + key);
    }

    String action(PlayerRef pr, World world, String action, String block, String from) {
        if (!authorized(pr)) return "Denied: operator permissions required";
        Session s = session(pr, world);
        WorldEditEngine eng = s.engine;
        try {
            switch (action) {
                case "pos1" -> { eng.pos1(atFeet(pr)); return "Position 1 set to " + eng.pos1(); }
                case "pos2" -> { eng.pos2(atFeet(pr)); return "Position 2 set to " + eng.pos2(); }
                case "fill" -> {validateBlock(block);eng.startFill(block);}
                case "replace" -> {validateBlock(from);validateBlock(block);eng.startReplace(from, block);}
                case "hollow" -> eng.startHollow(); // Removes interior only, keeping original surface blocks
                case "copy" -> eng.startCopy();
                case "paste" -> eng.startPaste(atFeet(pr), false);
                case "undo" -> eng.startUndo();
                case "redo" -> eng.startRedo();
                case "cancel" -> {eng.cancel();return eng.lastResult();}
                case "status" -> {return eng.status();}
                default -> {return "Unknown action";}
            }
            s.lastProgressTick = world.getTick();
            return eng.status() + " — editing in small batches each tick";
        } catch (RuntimeException e) { return "Error: " + e.getMessage(); }
    }
}
