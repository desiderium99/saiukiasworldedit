package dev.saiukia.worldedit;

import com.hypixel.hytale.codec.Codec;
import com.hypixel.hytale.codec.KeyedCodec;
import com.hypixel.hytale.codec.builder.BuilderCodec;
import com.hypixel.hytale.component.Ref;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.protocol.packets.interface_.CustomPageLifetime;
import com.hypixel.hytale.protocol.packets.interface_.CustomUIEventBindingType;
import com.hypixel.hytale.server.core.entity.entities.player.pages.InteractiveCustomUIPage;
import com.hypixel.hytale.server.core.ui.builder.UICommandBuilder;
import com.hypixel.hytale.server.core.ui.builder.UIEventBuilder;
import com.hypixel.hytale.server.core.ui.builder.EventData;
import com.hypixel.hytale.server.core.universe.PlayerRef;
import com.hypixel.hytale.server.core.universe.world.World;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;

public final class SaiukiasWorldeditPage extends InteractiveCustomUIPage<SaiukiasWorldeditPage.Click> {
    public static final class Click {
        public static final BuilderCodec<Click> CODEC = BuilderCodec.builder(Click.class, Click::new)
                .append(new KeyedCodec<>("Action", Codec.STRING), (d, s) -> d.action=s, d -> d.action).add()
                .append(new KeyedCodec<>("@Block", Codec.STRING), (d, s) -> d.block=s, d -> d.block).add()
                .append(new KeyedCodec<>("@From", Codec.STRING), (d, s) -> d.from=s, d -> d.from).add()
                .build();
        String action;
        String block;
        String from;
    }
    private final SaiukiasWorldeditPlugin plugin;
    private final World world;
    private String status = "OP only. Use /wewand, select corners, then choose an edit.";
    public SaiukiasWorldeditPage(SaiukiasWorldeditPlugin plugin, PlayerRef player, World world) {
        super(player, CustomPageLifetime.CanDismiss, Click.CODEC);
        this.plugin=plugin;
        this.world=world;
    }
    @Override public void build(Ref<EntityStore> ref, UICommandBuilder ui, UIEventBuilder events, Store<EntityStore> store) {
        if (!SaiukiasWorldeditPlugin.authorized(playerRef)) { close(); return; }
        ui.append("SaiukiasWorldedit.ui");
        ui.set("#Status.Text", status);
        String[] actions = {"pos1", "pos2", "fill", "replace", "hollow", "copy", "paste", "undo", "redo", "cancel", "status"};
        for (String action : actions) {
            EventData data = EventData.of("Action", action);
            // Only commands that actually need user-selected block IDs gather field values.
            if ("fill".equals(action) || "replace".equals(action))
                data.append("@Block", "#Block.Value");
            if ("replace".equals(action))
                data.append("@From", "#From.Value");
            events.addEventBinding(CustomUIEventBindingType.Activating, "#" + action, data, false);
        }
    }
    @Override public void handleDataEvent(Ref<EntityStore> ref, Store<EntityStore> store, Click data) {
        if (!SaiukiasWorldeditPlugin.authorized(playerRef)) { close(); return; }
        if (data != null && data.action != null) {
            // UI handler runs in the player's world context. No trust in action/data strings.
            status = plugin.action(playerRef, world, data.action,
                    data.block == null ? "" : data.block.trim(),
                    data.from == null ? "" : data.from.trim());
        }
        UICommandBuilder update = new UICommandBuilder();
        update.set("#Status.Text", status);
        sendUpdate(update);
    }
}
