package dev.saiukia.worldedit;

import java.util.*;

/** Single-world, single-operator editor. Jobs must be stepped ONLY on Hytale's world thread. */
public final class WorldEditEngine {
    public record Pos(int x, int y, int z) {
        public Pos offset(Pos p) { return new Pos(Math.addExact(x,p.x),Math.addExact(y,p.y),Math.addExact(z,p.z)); }
        public Pos subtract(Pos p) { return new Pos(Math.subtractExact(x,p.x),Math.subtractExact(y,p.y),Math.subtractExact(z,p.z)); }
    }
    public record Region(Pos min, Pos max) {
        public Region {
            Objects.requireNonNull(min); Objects.requireNonNull(max);
            Pos a=min,b=max;
            min=new Pos(Math.min(a.x,b.x),Math.min(a.y,b.y),Math.min(a.z,b.z));
            max=new Pos(Math.max(a.x,b.x),Math.max(a.y,b.y),Math.max(a.z,b.z));
        }
        public long volume() {
            return Math.multiplyExact(Math.multiplyExact((long)max.x-min.x+1, (long)max.y-min.y+1), (long)max.z-min.z+1);
        }
        public Iterable<Pos> positions() { return () -> new Iterator<>() {
            int x=min.x,y=min.y,z=min.z;
            boolean more=true;
            public boolean hasNext(){return more;}
            public Pos next(){
                if(!more)throw new NoSuchElementException();
                Pos p=new Pos(x,y,z);
                if(x<max.x)x++; else {x=min.x;if(z<max.z)z++; else {z=min.z;if(y<max.y)y++;else more=false;}}
                return p;
            }
        }; }
        public boolean isInterior(Pos p) {
            return p.x>min.x && p.x<max.x && p.y>min.y && p.y<max.y && p.z>min.z && p.z<max.z;
        }
    }
    public interface WorldAccess {
        String get(Pos pos);
        void set(Pos pos, String blockKey);
        boolean isLoaded(Pos pos);
    }
    private record Entry(Pos pos,String before,String after) {}
    private final WorldAccess world;
    private final int historyLimit;
    private final Deque<List<Entry>> undo=new ArrayDeque<>(), redo=new ArrayDeque<>();
    private Pos pos1,pos2;
    private Map<Pos,String> clipboard=Map.of();
    private Job active;
    private String lastResult="No edit queued";

    public WorldEditEngine(WorldAccess world,int historyLimit){
        this.world=Objects.requireNonNull(world);
        if(historyLimit<1)throw new IllegalArgumentException("invalid history limit");
        this.historyLimit=historyLimit;
    }
    public void pos1(Pos p){pos1=Objects.requireNonNull(p);}
    public void pos2(Pos p){pos2=Objects.requireNonNull(p);}
    public Pos pos1(){return pos1;}
    public Pos pos2(){return pos2;}
    public Region region(){if(pos1==null||pos2==null)throw new IllegalStateException("Select both corners first");return new Region(pos1,pos2);}
    private void loaded(Pos pos){if(!world.isLoaded(pos))throw new IllegalStateException("Unloaded section at "+pos);}
    private void record(List<Entry> changes){
        if(changes.isEmpty())return;
        undo.push(changes);while(undo.size()>historyLimit)undo.removeLast();redo.clear();
    }
    private void queue(Job job){
        if(active!=null)throw new IllegalStateException("Finish or cancel current operation first: "+active.label);
        active=job;
        lastResult="Queued "+job.label+" ("+job.total+" blocks)";
    }
    public boolean busy(){return active!=null;}
    public String status(){return active==null?lastResult:active.label+": "+active.processed+" / "+active.total+" checked, "+active.modified+" changed";}
    public String lastResult(){return lastResult;}
    public int step(int blockBudget,long deadlineNanos){
        if(active==null || blockBudget<1)return 0;
        return active.step(blockBudget,deadlineNanos);
    }
    public void cancel(){
        if(active!=null)active.finish("Cancelled",false);
    }

    public void startFill(String blockKey){
        Objects.requireNonNull(blockKey);Region r=region();
        queue(new RegionJob("Fill",r){@Override String replacement(Pos p,String before){return blockKey;}});
    }
    public void startReplace(String from,String to){
        Objects.requireNonNull(from);Objects.requireNonNull(to);Region r=region();
        queue(new RegionJob("Replace",r){@Override String replacement(Pos p,String before){return Objects.equals(from,before)?to:null;}});
    }
    /** Hollow clears ONLY strictly interior blocks; preserves each existing wall block and material. */
    public void startHollow(){
        Region r=region();queue(new RegionJob("Hollow",r){@Override String replacement(Pos p,String before){return r.isInterior(p)?"Empty":null;}});
    }
    public void startCopy(){
        Region r=region(); queue(new Job("Copy",r.volume()){
            final Iterator<Pos> positions=r.positions().iterator();
            final Map<Pos,String> snapshot=new HashMap<>();
            @Override boolean hasNext(){return positions.hasNext();}
            @Override void process(){Pos p=positions.next();loaded(p);snapshot.put(p.subtract(r.min),world.get(p));}
            @Override void onSuccess(){clipboard=snapshot;}
        });
    }
    public void startPaste(Pos at,boolean ignoreAir){
        Objects.requireNonNull(at);
        if(clipboard.isEmpty())throw new IllegalStateException("Clipboard empty");
        // Copy reference safely: a new clipboard cannot be started while this job is active.
        Map<Pos,String> snapshot=clipboard;
        queue(new ChangeJob("Paste",snapshot.size()){
            final Iterator<Map.Entry<Pos,String>> items=snapshot.entrySet().iterator();
            @Override boolean hasNext(){return items.hasNext();}
            @Override void process(){
                var e=items.next();Pos p=at.offset(e.getKey());loaded(p);
                if(!ignoreAir || !"Empty".equalsIgnoreCase(e.getValue()))change(p,e.getValue());
            }
        });
    }
    public void startUndo(){
        if(undo.isEmpty())throw new IllegalStateException("Nothing to undo");
        List<Entry> entries=undo.peek();
        queue(new Job("Undo",entries.size()){
            int index=entries.size()-1;
            @Override boolean hasNext(){return index>=0;}
            @Override void process(){Entry e=entries.get(index--);loaded(e.pos);world.set(e.pos,e.before);modified++;}
            @Override void onSuccess(){undo.pop();redo.push(entries);}
        });
    }
    public void startRedo(){
        if(redo.isEmpty())throw new IllegalStateException("Nothing to redo");
        List<Entry> entries=redo.peek();
        queue(new Job("Redo",entries.size()){
            int index=0;
            @Override boolean hasNext(){return index<entries.size();}
            @Override void process(){Entry e=entries.get(index++);loaded(e.pos);world.set(e.pos,e.after);modified++;}
            @Override void onSuccess(){redo.pop();undo.push(entries);}
        });
    }
    public boolean hasClipboard(){return !clipboard.isEmpty();}

    private abstract class Job {
        final String label; final long total;
        long processed; int modified;
        Job(String label,long total){this.label=label;this.total=total;}
        abstract boolean hasNext();
        abstract void process();
        void onSuccess(){}
        void onStop(boolean success){}
        int step(int limit,long deadlineNanos){
            int scanned=0;
            try {
                while(scanned<limit && (scanned==0 || System.nanoTime()<deadlineNanos) && hasNext()){
                    process();scanned++;processed++;
                }
                if(!hasNext())finish("Complete",true);
            }catch(RuntimeException e){
                finish("Stopped: "+e.getMessage(),false);
            }
            return scanned;
        }
        void finish(String message,boolean success){
            if(success)onSuccess();
            onStop(success);
            lastResult=label+" "+message+" ("+processed+" checked, "+modified+" modified)";
            active=null;
        }
    }
    private abstract class ChangeJob extends Job {
        final List<Entry> changes=new ArrayList<>();
        ChangeJob(String label,long total){super(label,total);}
        final void change(Pos p,String after){
            if(after==null)return;
            String before=world.get(p);
            if(!Objects.equals(after,before)){
                world.set(p,after);
                changes.add(new Entry(p,before,after));modified++;
            }
        }
        @Override void onStop(boolean success){
            // Incomplete edits must remain undoable: do not leave a partly changed world with no history.
            record(changes);
        }
    }
    private abstract class RegionJob extends ChangeJob {
        final Iterator<Pos> positions;
        RegionJob(String label,Region region){super(label,region.volume());positions=region.positions().iterator();}
        @Override boolean hasNext(){return positions.hasNext();}
        abstract String replacement(Pos pos,String before);
        @Override void process(){
            Pos p=positions.next();loaded(p);
            String before=world.get(p);String after=replacement(p,before);
            if(after!=null && !Objects.equals(after,before)){
                world.set(p,after);changes.add(new Entry(p,before,after));modified++;
            }
        }
    }
}
